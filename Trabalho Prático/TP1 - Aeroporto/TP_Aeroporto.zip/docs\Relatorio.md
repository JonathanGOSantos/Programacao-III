# Relatório do Trabalho Prático 1 - Aeroporto

## 1. Decisões de Especificação e Estruturas de Dados

### 1.1 Decisão sobre a Identificação dos Aviões e Balanceamento
Conforme detalhe de especificação, optou-se por utilizar um **ID sequencial contínuo e sem distinção** fixa par/ímpar entre aviões de pouso ou decolagem. Para diferenciar o objetivo de cada avião e permitir um balanceamento mais justo na distribuição das filas, adotou-se o uso explícito do enum `Operacao` (`POUSO` ou `DECOLAGEM`). 

Dessa forma, a Torre de Controle decide para qual prateleira enviar o avião avaliando dinamicamente a menor fila disponível para aquela `Operacao` específica naquele instante. Isso mitiga a criação de gargalos não naturais e não restringe o sistema a assumir a natureza da operação com base em propriedades numéricas do ID, tornando a arquitetura mais orientada a objetos e autoexplicativa.

### 1.2 Estruturas de Dados Utilizadas
* **Filas de Espera (Prateleiras):** Implementadas utilizando a interface `Queue` (através da classe concreta `LinkedList`). Esta escolha é essencial para o algoritmo, pois assegura que a entrada de novos aviões no fim da fila e a remoção dos aviões priorizados no início ocorram de forma eficiente e mantenham a ordem de chegada íntegra (comportamento FIFO - First-In, First-Out).
* **Torre de Controle (Gerenciamento de Entidades):** Utilizou-se dicionários `Map<Integer, Prateleira>` e `Map<Integer, Pista>` para organizar o acesso. Essa estrutura de dados facilita o acesso direto de leitura (tempo constante) através do identificador numérico da entidade (Pista 1, Pista 2, etc.) na hora de realizar a intersecção de qual prateleira despeja tráfego em qual pista.
* **Registros e Estatísticas:** Para armazenar os dados imutáveis de acontecimentos temporais, adotou-se a estrutura `record` (introduzida no Java 14+), tornando os dados encapsulados por padrão. O histórico é agrupado com `List` nativas e filtrado utilizando a `Stream API` do Java.

---

## 2. Listagem dos Testes Executados

Os testes unitários focaram nas lógicas de domínio primárias de cada entidade, assegurando a confiabilidade da simulação de tempo e alocação. Os testes, desenvolvidos sob o escopo do **JUnit 5**, são:

1. **AviaoTest:** 
   - Valida a instanciação sem perda de integridade dos dados (ID e operação corretos).
   - Verifica o decréscimo sucessivo de combustível e as barreiras que impedem combustível negativo.
   - Testa a flag booleana de estado de emergência (acionada estritamente quando combustível é 0).
2. **PrateleiraTest:** 
   - Testes de FIFO: garantir que o primeiro avião inserido é impreterivelmente o primeiro a ser resgatado.
   - Avaliação da ação de passagem do tempo envelhecendo/reduzindo em -1 o tanque de toda a fila simultaneamente.
   - Filtro de busca seletiva dentro da fila para detecção isolada de aeronaves em emergência.
3. **PistaTest:** 
   - Atesta o controle de bloqueio (se uma pista está livre para um evento no instante atual ou ocupada).
4. **TorreDeControleTest:** 
   - Confirma a integração que avança o "relógio" virtual (`instante`), roteia novos aviões em background para a fila correta e processa a alocação.
5. **EstatisticasTest:** 
   - Comprova a precisão dos cálculos matemáticos responsáveis por agregar dezenas de `Registros` esparsos, convertendo-os em métricas reais (Ex: Tempo Médio Geral) através das etapas corretas do ciclo de vida da simulação.

---

## 3. Estudo da Complexidade de Tempo (Notação Big-O)

A análise abaixo reflete o comportamento assintótico de pior caso, com a seguinte legenda das variáveis independentes:
* **F** = Número total de filas (prateleiras). O limite é uma constante fixa muito pequena (4 para pouso e 3 para decolagem).
* **A** = Número de aviões simultaneamente armazenados dentro de uma fila no momento avaliado.
* **R** = Quantidade absoluta de Registros salvos no sistema, que cresce progressivamente ao longo da vida útil da simulação.

### Inserção e Remoção em Filas
* `Prateleira.adicionarAviao(Aviao)` e `Prateleira.removerPrimeiroAviao()`: **O(1)**
  * A utilização de listas ligadas (`LinkedList`) faz com que a realocação de ponteiros para adicionar ou extrair aeronaves nas pontas da fila não dependa do tamanho global da fila, sendo resolvida de maneira instantânea e direta.

### Processamento e Balanceamento na Torre
* `TorreDeControle.processarAviao(Aviao)`: **O(F)**
  * Para efetuar o balanceamento natural, a Torre avalia o valor numérico (tamanho da fila `size()`) em cada uma das opções candidatas para localizar a opção menos superlotada. A complexidade é tecnicamente linear em relação a F, porém, uma vez que as especificações limitam F ao máximo de 4 pistas, na prática assume o impacto imperceptível de complexidade de tempo constante **O(1)**.

### Avanço Temporal e Varredura de Emergência
* `TorreDeControle.processarPistas()` e `alocarPistasParaEmergencias()`: **O(F × A)**
  * O gargalo prático do avanço temporal. A cada pulso do clock, o código realiza uma travessia completa em todas as prateleiras de descida para decrementar o combustível e localizar candidatos críticos. Como a iteração olha para todos os N aviões de todas as M filas para agir, o comportamento aproxima-se do crescimento de complexidade baseando-se em $F \times A$.

### Cálculo Retrospectivo de Estatísticas
* `Estatisticas.tempoMedioDePouso()` e `tempoMedioDeDecolagem()`: **O(R)**
  * Quando requisitada (seja por logs ou impressão na tela), as médias processam integralmente o acúmulo das transações e eventos (`Stream`). A operação percorre, mapeia e efetua agrupamentos lógicos de toda a coleção histórica, tornando a operação uma leitura linear total sobre a base de dados em memória. Isso significa que quanto mais a simulação rodar, maior será o peso da exibição dessa conta. Para o contexto do trabalho, **O(R)** é suficiente, embora num cenário crítico real este valor devesse ser pré-cacheado em O(1) a cada alteração.
